docker stop zilliqa_scillaserver
docker run --rm -d  -p 4000:4000 --name=zilliqa_scillaserver zilliqa_scillaserver:1