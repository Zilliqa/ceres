# Scilla Server

## Checker


## Development / Local

You need to install Scilla into /scilla dir.