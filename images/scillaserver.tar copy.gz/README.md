# Dockerized Scilla Server with HTTP API

This should run on port 4000